# GHOST/OS — Neural Agent Terminal (Puter.js Edition)

```
██████╗ ██╗  ██╗ ██████╗ ███████╗████████╗
██╔════╝ ██║  ██║██╔═══██╗██╔════╝╚══██╔══╝
██║  ███╗███████║██║   ██║███████╗   ██║
██║   ██║██╔══██║██║   ██║╚════██║   ██║
╚██████╔╝██║  ██║╚██████╔╝███████║   ██║
 ╚═════╝ ╚═╝  ╚═╝ ╚═════╝ ╚══════╝   ╚═╝

Puter.js Edition  •  100% Free  •  No API Key Needed
```

**GHOST/OS** is a fully browser-based AI-native operating system terminal.
It looks and feels like a real retro Unix terminal, but routes every command
through a live AI agent powered by **Puter.js** — completely free, no API key,
no sign-up — that can search the web, manage persistent notes, execute JavaScript,
and iterate across multiple steps to complete complex tasks.

> **One file. Zero cost. Zero setup. Deploy in 60 seconds.**

---

## Why Puter.js?

| | Anthropic API | **Puter.js** |
|---|---|---|
| Cost | Pay per token | **Free** |
| API key required | Yes | **No** |
| Setup | npm + env vars | **Script tag** |
| Models available | Claude only | Claude, GPT-4o, Gemini |
| Works in browser | Needs special headers | **Native** |

Puter.js (`https://js.puter.com/v2/`) provides free AI model access and a
persistent key-value store — all from a single `<script>` tag.

---

## Table of Contents

1. [Project Structure](#1-project-structure)
2. [Architecture](#2-architecture)
3. [The ReAct Agent Loop](#3-the-react-agent-loop)
4. [Tools Reference](#4-tools-reference)
5. [Hallucination Detection](#5-hallucination-detection)
6. [Session and Memory](#6-session-and-memory)
7. [Built-in Commands](#7-built-in-commands)
8. [Local Development](#8-local-development)
9. [Deploy to Vercel](#9-deploy-to-vercel)
10. [Deploy to GitHub Pages](#10-deploy-to-github-pages)
11. [Deploy to Netlify](#11-deploy-to-netlify)
12. [Customisation Guide](#12-customisation-guide)
13. [AI Agent Demo Commands](#13-ai-agent-demo-commands)
14. [Limitations](#14-limitations)

---

## 1. Project Structure

```
ghost-os-puter/
├── index.html          ← The entire application (~1300 lines, HTML + CSS + JS)
├── vercel.json         ← Vercel deployment config
├── .gitignore
├── README.md           ← This file
└── AI_AGENT_SKILLS.md  ← Deep dive: how agent skills are demonstrated
```

Everything lives in `index.html`. No build step, no package manager, no transpilation.
The file loads one external script (`puter.js`) and nothing else.

---

## 2. Architecture

```
Browser (index.html)
│
├── CRT Terminal UI (scanlines, vignette, amber prompt, HAL badge)
├── Info Modal (6 tabs: What / Why Special / Tools / HAL / Memory / How-to)
│
└── handleCmd(input)
    ├── Built-ins: clear, help, date, sysinfo, notes, info (instant)
    └── AI path → runAgent(cmd)
                    │
                    ├── Build messages[] with full conv history
                    ├── puter.ai.chat(messages, {model}) ──► Puter.js FREE AI
                    ├── Parse [TOOL: name] {"args"} from response
                    ├── execTool(name, args)
                    │     ├── web_search  → puter.ai.chat (search prompt)
                    │     ├── save_note   → puter.kv.set()
                    │     ├── read_note   → puter.kv.get()
                    │     ├── list_notes  → puter.kv.get("note_index")
                    │     ├── delete_note → puter.kv.del()
                    │     ├── run_js      → new Function(code)()
                    │     └── get_datetime → new Date()
                    ├── Append TOOL_RESULT, loop (max 8 iterations)
                    └── Return final text to terminal

Parallel (non-blocking):
└── checkHallucination(text) → puter.ai.chat → JSON → HalBadge

Storage:
├── sessionStorage  → terminal lines + cmd history + conv (tab-scoped)
├── localStorage    → intro_seen flag (permanent)
└── puter.kv        → notes (permanent, cloud-synced)
```

---

## 3. The ReAct Agent Loop

Puter.js uses a chat completion interface, not native function-calling schemas.
GHOST/OS implements the **ReAct (Reasoning + Acting) pattern** — the same
technique used in LangChain, AutoGPT, and the original ReAct paper (Yao et al., 2022).

### The Text Tool Protocol

The system prompt teaches the model a text-based tool syntax:

```
[TOOL: tool_name] {"param": "value"}
```

The JavaScript regex `\[TOOL:\s*(\w+)\]\s*(\{[^}]*\})` extracts every tool call
from the model's response, executes each one, and feeds results back as:

```
TOOL_RESULT: tool_name
<result text here>
```

### A Full Loop Example

```
User: "search latest AI news and save a summary to notes"

Iteration 1:
  Model → "I'll search for that.
           [TOOL: web_search] {"query": "latest AI news 2025"}"
  JS    → execTool("web_search", {query: "..."})
        → appends "TOOL_RESULT: web_search\n[results]"
  Loop continues.

Iteration 2:
  Model → "Good. Now saving the summary.
           [TOOL: save_note] {"key": "ai-news", "content": "..."}"
  JS    → execTool("save_note", {key: "ai-news", content: "..."})
        → appends "TOOL_RESULT: save_note\nNote saved."
  Loop continues.

Iteration 3:
  Model → "Done. I searched for the latest AI news and saved
           a summary under 'ai-news'. Key findings: ... [DONE]"
  JS    → No [TOOL:] found → exits loop → returns text to terminal
```

The model's reasoning text before each tool call is displayed in the terminal
in dim italic — you see the agent thinking in real time.

---

## 4. Tools Reference

### `web_search`
```json
{"query": "search terms here"}
```
Implemented by asking Puter AI to search and summarize the web.
Used automatically for news, current events, prices, facts.

### `save_note` / `read_note` / `list_notes` / `delete_note`
```json
{"key": "note-name", "content": "..."}   // save
{"key": "note-name"}                      // read / delete
{}                                         // list
```
Backed by `puter.kv` — permanent Puter cloud key-value storage.
Notes survive browser close, device switch, everything.

### `run_js`
```json
{"code": "return Math.pow(2, 32)"}
```
Executes JavaScript via `new Function(code)`. Use `return` to get a result.

### `get_datetime`
```json
{}
```
Returns current date, time, day of week, timezone. Grounds the agent in
real time without any external dependency.

---

## 5. Hallucination Detection

After every AI response, a second parallel `puter.ai.chat()` call analyzes
the output with a strict detection prompt. Non-blocking — terminal output
appears immediately, badge updates asynchronously.

```javascript
// Fires in parallel — does NOT delay terminal output
checkHallucination(text).then(r => setHalBadge(r || null));
```

Returns structured JSON:
```json
{"hallucinated": true, "confidence": "high", "reason": "Fabricated statistic"}
```

**Badge states:**
- ⚫ GREY  → `HAL-CHECK RUNNING` (checking in progress)
- 🟢 GREEN → `HAL-CHECK: GROUNDED` (no issues found)
- 🔴 RED   → `HALLUCINATION DETECTED [HIGH]` (hover for reason)

**Flags:** Fabricated stats, invented citations/URLs, made-up named entities,
suspicious overconfidence, internal contradictions.

**Does NOT flag:** General knowledge, labeled opinions, code, math results,
web search summaries (those are grounded by definition).

---

## 6. Session and Memory

| Storage | Contents | Lifetime |
|---|---|---|
| `sessionStorage` | Terminal lines (last 500), cmd history (last 100), conv history (last 40 turns) | Survives refresh. Wiped on tab close. |
| `localStorage` | Only `ghostos_intro_seen` flag | Permanent until browser data cleared |
| `puter.kv` | Notes from `save_note` | Permanent, cloud-synced |

Session is saved on every state change via a `saveSession()` call that writes
to `sessionStorage`. On page load, the saved session is restored before the OS
starts — so a refresh feels seamless.

---

## 7. Built-in Commands

| Command | Description |
|---|---|
| `help` | Full command reference |
| `clear` | Wipe terminal output |
| `history` | Show command history |
| `whoami` | User info |
| `date` | Date, time, epoch, timezone |
| `sysinfo` | OS version, model, tools |
| `notes` | List all Puter KV note keys |
| `info` | Open the info/about modal |

---

## 8. Local Development

No build tools needed. Just open the file.

```bash
# Simplest — open directly
open index.html

# Better — serve locally (avoids some browser security restrictions)
python3 -m http.server 3000
# Visit http://localhost:3000

# VS Code users
# Right-click index.html → "Open with Live Server"
```

**Changing the model** — find this constant near the top of the `<script>` block:

```javascript
const MODEL = 'claude-sonnet-4-5';
```

Other Puter.js model strings:

| String | Description |
|---|---|
| `claude-sonnet-4-5` | Default — fast and capable |
| `claude-opus-4-5` | Most capable |
| `gpt-4o` | OpenAI GPT-4o |
| `gpt-4o-mini` | Faster GPT-4o |
| `gemini-1.5-flash` | Google Gemini Flash |

Full list: https://docs.puter.com/ai/

---

## 9. Deploy to Vercel

### Option A — Vercel CLI (~60 seconds)

```bash
# Install CLI
npm i -g vercel

# From project root
vercel

# Prompts:
#   Set up and deploy? → Y
#   Which scope?       → your account
#   Link to existing?  → N
#   Project name?      → ghost-os
#   Directory?         → ./
#   Override settings? → N

# Deploy to production:
vercel --prod
```

Live at `https://ghost-os-XXXX.vercel.app`.

### Option B — GitHub + Vercel Dashboard

```bash
git init
git add .
git commit -m "feat: GHOST/OS Puter.js edition"
git remote add origin https://github.com/YOUR_USER/ghost-os.git
git push -u origin main
```

1. Go to https://vercel.com/new
2. Import your GitHub repo
3. Framework Preset: **Other**
4. Build Command: *(leave empty)*
5. Output Directory: *(leave empty)*
6. Click **Deploy**

Every `git push` to `main` auto-redeploys.

### Option C — Drag and Drop

1. Go to https://vercel.com/new
2. Drag the `ghost-os-puter` folder onto the page
3. Click **Deploy**

Done in ~30 seconds.

### vercel.json explained

```json
{
  "rewrites": [{"source": "/(.*)", "destination": "/index.html"}]
}
```

Routes everything to `index.html` (standard static SPA config).
The headers block adds security best practices.

---

## 10. Deploy to GitHub Pages

```bash
git init && git add . && git commit -m "init"
git remote add origin https://github.com/YOUR_USER/ghost-os.git
git push -u origin main
```

In GitHub repo: **Settings → Pages → Deploy from branch → main / (root) → Save**

Live at `https://YOUR_USER.github.io/ghost-os/` in ~2 minutes.

---

## 11. Deploy to Netlify

```bash
# CLI
npm i -g netlify-cli
netlify deploy --dir . --prod

# Or drag & drop at https://app.netlify.com/drop
```

No `netlify.toml` needed for a single HTML file.

---

## 12. Customisation Guide

### Add a new tool

**In the `TOOL_DEFS` string** (inside `AGENT_SYSTEM`):
```
- my_tool  {"param": "description"}  — what it does
```

**In `execTool()`**:
```javascript
if (name === 'my_tool') {
  return String(doSomething(args.param));
}
```

### Add a built-in command

```javascript
const BUILTINS = {
  mycommand() {
    return 'LINE 1\nLINE 2\n[DONE]';
  },
};
```

### Change system prompt personality

Edit `AGENT_SYSTEM`. The output format rules (dividers, key-value syntax,
`[DONE]` endings) are all defined there and can be changed freely.

### Change colour scheme

Edit CSS variables at the top of `<style>`:
```css
:root {
  --green:    #b8ffa0;  /* default text */
  --amber:    #ffe066;  /* prompt */
  --cyan:     #44ffaa;  /* [DONE] */
  --red:      #ff5555;  /* errors */
  --blue:     #66aaff;  /* tool calls */
}
```

---

## 13. AI Agent Demo Commands

### Web search
```
search latest AI news today
current bitcoin price
who won the last IPL tournament
```

### Calculations via run_js
```
calculate compound interest on 50000 at 8.5% for 20 years
what is 18% gst on 4750
run: return new Date().toLocaleDateString('en-IN',{weekday:'long'})
```

### Notes — persistent across sessions
```
save note goals = ship ghost-os this week
read note goals
list all notes
delete note goals
```

### Multi-step chaining (showcases real agentic behaviour)
```
search the latest Claude API updates and save a summary as claude-updates
```
Watch: `web_search` → get results → `save_note` → confirm. Three tool calls,
zero human intervention between them.

```
what day is it today and how many days until december 31
```
Watch: `get_datetime` → `run_js` to calculate difference → final answer.

### Hallucination detection demo

Trigger RED badge:
```
what are the exact enterprise AI adoption statistics for india in 2024
```

Trigger GREEN badge (search-grounded):
```
search when was anthropic founded and who are the founders
```

---

## 14. Limitations

| Issue | Notes |
|---|---|
| Puter.js rate limits | Free tier is generous but finite. Add retry logic for heavy use. |
| `web_search` quality | Implemented as a second AI call, not a native search API. |
| `run_js` sandboxing | Uses `new Function()` in main thread. For production, run in a Web Worker. |
| `puter.kv` list | No native list op — uses a manual `note_index` key. Two-tab concurrent edits may corrupt index. |
| Tool protocol reliability | Text-based ReAct is less reliable than native function-calling. Occasionally the model may format a tool call incorrectly. |
| sessionStorage quota | Capped at 500 lines / 40 turns automatically to stay under 5MB. |
| Offline | Requires `js.puter.com` to be reachable. No offline mode. |

---

## License

MIT — fork it, deploy it, build on it.

---

*GHOST/OS v4.0 · Puter.js · 100% free · single HTML file · no build step*
